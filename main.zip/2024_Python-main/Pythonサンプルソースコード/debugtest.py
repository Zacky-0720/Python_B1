num1 = 1
num2 = 2
num3 = 3

mid1 = num1 + num2
mid2 = num1 * num3
mid3 = num2 + num3

print (mid1, mid2, mid3)