import sys
args = sys.argv

#引数を変数に代入
name = args[1] 

print("Hello " + name + " !", end="")
