#入力
name = input('What\'s your name ?') 

#入力された名前の出力
print('Hello ' + name + ' !', end="")
