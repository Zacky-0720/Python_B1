#出力
print("Hello, world!", end="")
